from logging.config import dictConfig
from .api_handler import ExternalApiHandler
from .formatter import JsonFormatter

def configure_observer(api_url=None, error_key=None):

    if api_url and error_key:
        logging_config = {
            'version': 1,
            'disable_existing_loggers': True,
            'formatters': { # Define formatter using custom JsonFormatter
                'json': {
                    '()': JsonFormatter,
                },
            },
            'handlers': {
                # 'external_api': {
                #     'formatter':'json',
                #     '()': ExternalApiHandler,
                #     'api_url': api_url,
                #     'error_key': error_key,
                #     'level': 'ERROR',
                # },
                'console':{
                    'formatter':'json',
                    'class':'logging.StreamHandler',
                    'level': 'ERROR',
                },
            },
            'loggers': {
                '': {
                    'handlers': ['console'],
                    'level': 'ERROR',  
                    'propagate': True,
                },
            },
        }
        # Apply the logging configuration
        dictConfig(logging_config)
    else: 
        raise ValueError('Missing api_url or error_key while configure the error observer app')