import logging
import requests

class ExternalApiHandler(logging.Handler):
    """
    Initialize the ExternalApiHandler with the specified API URL.
    Args:
    api_url (str): The URL of the external API to which logs will be sent.
    """
    def __init__(self, api_url, error_key):
        super().__init__()
        self.api_url = api_url
        self.error_key = error_key

    def emit(self, record):
        """
        Emit a log record to the external API.
        Args:
            record (LogRecord): The log record to be emitted.
        """
        try:
            log_entry = self.format(record)  
            self.send_to_external_api(log_entry) 
        except Exception as e:
            raise

    def send_to_external_api(self, log_entry):
        """
        Send a formatted log entry to the external API.
        Args:
            log_entry (str): The formatted log entry to be sent.
        """
        try:
             # Prepare headers for the HTTP request to the external API
            headers = {
                'Content-Type': 'application/json',
                'ERROR-API-KEY': self.error_key
            }
            response = requests.post(self.api_url, data=log_entry, headers=headers)
            response.raise_for_status()
            
        except requests.RequestException as e:
            raise