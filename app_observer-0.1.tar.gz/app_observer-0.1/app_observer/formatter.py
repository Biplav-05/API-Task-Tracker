import logging
import json

class JsonFormatter(logging.Formatter):
    LOGGING_CONFIG = None

    def format(self, record):
        log_data = {
            'level': record.levelname,
            'message': record.getMessage(),
            'client_timestamp': self.formatTime(record),
            'logger': record.name,
            'filename': record.filename,
            'module': record.module,
            'lineno': record.lineno,
            'funcName': record.funcName,
        }

        # Include stack trace information for ERROR and CRITICAL levels
        if record.exc_info:
            log_data['stack_trace'] = self.formatException(record.exc_info)

        return json.dumps(log_data)